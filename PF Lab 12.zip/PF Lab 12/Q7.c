#include <stdio.h>
#include <ctype.h>
#include <string.h>

int isPal(char *s, int l, int r) {
    if (l >= r) return 1;
    if (tolower(s[l]) != tolower(s[r])) return 0;
    return isPal(s, l + 1, r - 1);
}

int main() {
    char str[200];
    printf("Enter string: ");
    scanf("%s", str);

    if (isPal(str, 0, strlen(str) - 1))
        printf("Palindrome");
    else
        printf("Not Palindrome");

    return 0;
}
