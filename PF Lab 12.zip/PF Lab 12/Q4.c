#include <stdio.h>
#include <stdlib.h>

int main() {
    int *arr;
    int n = 5;

    arr = (int*) calloc(n, sizeof(int));
    printf("Values after calloc:\n");
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);

    for (int i = 0; i < n; i++)
        arr[i] = i + 1;

    printf("\nModified:\n");
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);

    free(arr);

    arr = (int*) malloc(n * sizeof(int));
    printf("\nNew memory after malloc:\n");
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);

    free(arr);
    return 0;
}
