#include <stdio.h>

int main() {
    int arr[] = {10, 20, 30, 40, 50, 60, 70};
    int *ptr = arr;  
    
    printf("%d ", *ptr);        
    printf("%d ", *(ptr + 2));  
    printf("%d ", ptr[3]);      
    
    ptr += 4;  
    printf("%d ", *ptr);        
    printf("%d ", *(ptr + 1));  
    printf("%d ", *(ptr + 2));   
    
    int *ptr2 = &arr[5];  
    printf("\nUsing new pointer: %d\n", *ptr2);
    
    return 0;
}
