#include <stdio.h>

float checkResult(int m1, int m2, int m3) {
    float avg = (m1 + m2 + m3) / 3.0;

    if (avg >= 50 && m1 >= 40 && m2 >= 40 && m3 >= 40) {
        printf("PASS\n");
    } else {
        printf("FAIL - Reason: ");
        if (avg < 50) printf("Average below 50 ");
        if (m1 < 40 || m2 < 40 || m3 < 40) printf("Subject marks below 40");
        printf("\n");
    }
    return avg;
}

int main() {
    int m1, m2, m3;
    printf("Enter marks of 3 subjects: ");
    scanf("%d %d %d", &m1, &m2, &m3);

    float avg = checkResult(m1, m2, m3);
    printf("Average = %.2f\n", avg);
    return 0;
}
