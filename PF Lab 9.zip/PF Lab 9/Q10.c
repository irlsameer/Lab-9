#include <stdio.h>

int main() {
    int grid[3][4] = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9,10,11,12}
    };

    int *p = &grid[0][0];
    int *p2 = &grid[1][0]; 

    
    printf("%d ", *p);       
    printf("%d ", *(p + 2)); 
    printf("%d ", *(p + 4)); 
    printf("%d ", *(p + 6)); 

    
    printf("%d ", *(p2 - 1)); 

    
    printf("\nDivisible by 3: ");
    for(int i = 0; i < 12; i++) {
        if (*(p + i) % 3 == 0)
            printf("%d ", *(p + i));
    }

    
    printf("\nLast element: %d\n", *(&grid[0][0] + 11));

    return 0;
}
