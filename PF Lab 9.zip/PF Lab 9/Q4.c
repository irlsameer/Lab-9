#include <stdio.h>

float shipping(float amount, float weight) {
    if (amount > 100) return amount;

    if (weight < 2) return amount + 10;
    else if (weight <= 5) return amount + 15;
    else return amount + 20;
}

int main() {
    float amount, w;
    printf("Enter order amount and weight: ");
    scanf("%f %f", &amount, &w);

    printf("Total Cost: %.2f\n", shipping(amount, w));
    return 0;
}
