#include <stdio.h>

float totalBill(float food, int people) {
    float tax = food * 0.08;
    float tip = (food > 50) ? food * 0.15 : food * 0.10;
    float service = (people > 6) ? food * 0.05 : 0;

    return food + tax + tip + service;
}

int main() {
    float food;
    int people;
    printf("Enter food cost and number of people: ");
    scanf("%f %d", &food, &people);
    
    printf("Total Bill: %.2f\n", totalBill(food, people));
    return 0;
}
