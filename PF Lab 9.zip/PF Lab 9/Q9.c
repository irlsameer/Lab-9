#include <stdio.h>

int main() {
    int a = 100, b = 200, c = 300;
    int *p1 = &a, *p2 = &b, *p3 = &c;

    // First round: pointer swapping
    int *temp = p1;
    p1 = p2;   // p1 -> b
    p2 = p3;   // p2 -> c
    p3 = temp; // p3 -> a

    // Modify values through pointers
    *p1 += 50;  // b = 200 + 50 = 250
    *p2 -= 100; // c = 300 - 100 = 200
    *p3 *= 2;   // a = 100 * 2 = 200

    // Second reassignment
    p1 = &c;
    p2 = &a;
    p3 = &b;

    // More changes
    *p1 += 100; // c = 200 + 100 = 300
    *p2 += 200; // a = 200 + 200 = 400
    *p3 -= 100; // b = 250 - 100 = 150

    printf("Final Values:\n");
    printf("a = %d\nb = %d\nc = %d\n", a, b, c);

    return 0;
}
#include <stdio.h>

int main() {
    int a = 100, b = 200, c = 300;
    int *p1 = &a, *p2 = &b, *p3 = &c;

   
    int *temp = p1;
    p1 = p2;   
    p2 = p3;  
    p3 = temp; 

    
    *p1 += 50;  
    *p2 -= 100; 
    *p3 *= 2;   

    p1 = &c;
    p2 = &a;
    p3 = &b;

   
    *p1 += 100; 
    *p2 += 200; 
    *p3 -= 100; 

    printf("Final Values:\n");
    printf("a = %d\nb = %d\nc = %d\n", a, b, c);

    return 0;
}
