#include <stdio.h>

float processTransaction(float limit, float amount) {
    if (amount <= limit) {
        printf("APPROVED\n");
        return limit - amount;
    } else {
        printf("DECLINED\n");
        return limit;
    }
}

int main() {
    float limit = 5000, amount;
    printf("Enter transaction amount: ");
    scanf("%f", &amount);

    limit = processTransaction(limit, amount);
    printf("Remaining Limit: %.2f\n", limit);
    return 0;
}
