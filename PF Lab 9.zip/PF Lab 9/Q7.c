#include <stdio.h>

float rentalCost(int days, int km) {
    float cost = days * 40;
    int allowed = days * 100;

    if (km > allowed)
        cost += (km - allowed) * 0.25;

    if (days >= 7)
        cost *= 0.90;  

    return cost;
}

int main() {
    int days, km;
    printf("Enter rental days and km driven: ");
    scanf("%d %d", &days, &km);

    printf("Final Cost: %.2f\n", rentalCost(days, km));
    return 0;
}
