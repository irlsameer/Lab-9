#include <stdio.h>

int tempAlert(float temp) {
    if (temp > 35)
        return 1;
    else if (temp < 10)
        return 2;
    else if (temp >= 15 && temp <= 25)
        return 3;
    else
        return 4;
}

int main() {
    float t;
    printf("Enter temperature: ");
    scanf("%f", &t);

    int code = tempAlert(t);

    if (code == 1) printf("HEAT ALERT\n");
    else if (code == 2) printf("COLD ALERT\n");
    else if (code == 3) printf("COMFORT ZONE\n");
    else printf("NORMAL CONDITIONS\n");

    return 0;
}
